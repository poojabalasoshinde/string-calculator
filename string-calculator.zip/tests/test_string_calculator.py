from calculator.string_calculator import StringCalculator


def test_placeholder():
    assert True  
