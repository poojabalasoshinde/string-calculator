class StringCalculator:
    def __init__(self):
        self.call_count = 0

    def add(self, numbers: str) -> int:
        pass

    def get_called_count(self) -> int:
        return self.call_count
